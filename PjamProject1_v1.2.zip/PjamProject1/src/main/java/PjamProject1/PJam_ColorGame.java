package PjamProject1;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nathan
 */
public class PJam_ColorGame extends javax.swing.JFrame {
    //Array of colors and strings for text
    private final Color [] colorArr = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.MAGENTA};
    private final String [] colorTxtArr = {"Red", "Blue", "Green", "Yellow", "Purple"};
    private Color buttonColor;
    private String currentText;
    private final int [] randomXLocations = {90, 180, 270, 360, 450};
    private final int xSize = randomXLocations.length;
    private final int [] randomYLocations = {135, 160, 180, 200, 220, 240, 260, 280};
    private final int ySize = randomYLocations.length;
    ArrayList<Integer> chosenXLocations = new ArrayList<>();
    public static int highscore;
    private int roundsRemaining = 5;
    
    public String keyDisplay = "display";
    public String keyHide = "hide";
    public String keyExit = "exit";
    
    /**
     * Creates new form PJam_ColorGame
     */
    public PJam_ColorGame() {
        this.highscore = PjamPlay.highScore;
        initComponents();
        
        Action displayAction = new AbstractAction("display") {
            @Override
            public void actionPerformed(ActionEvent e) {
               displayImage();
            }
        };
           
        Action hideAction = new AbstractAction("hide") {
            @Override
            public void actionPerformed(ActionEvent e) {
               hideImage();
            }
        };
        
        Action exitAction = new AbstractAction("exit") {
            @Override
            public void actionPerformed(ActionEvent e) {       
                exitGame();
            }
        };
           
        imageForF1.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("F1"), keyDisplay);
        imageForF1.getActionMap().put(keyDisplay, displayAction);
        
        imageForF1.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("F2"), keyHide);
        imageForF1.getActionMap().put(keyHide, hideAction);
        
        imageForF1.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), keyExit);
        imageForF1.getActionMap().put(keyExit, exitAction);
        
        //Basic window formatting
        setLayout(null);
        setTitle("Color Game");
        setPreferredSize(new Dimension(600, 400));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        this.pack();
        setLocationRelativeTo(null);
        
        //Label is given random color and random string
        buttonColor = colorArr[(int) (Math.random() * 5)];
        currentText = colorTxtArr[(int) (Math.random() * 5)];
        colorText.setForeground(buttonColor);
        colorText.setText(currentText);
        
        //Set highscore and rounds remaining label to base values
        highscoreLabel.setText("Highscore = " + highscore);
        roundsLabel.setText("Rounds Remaining: " + roundsRemaining);
        
        //Set up buttons to be at random locations
        //BLUE BUTTON location
        int blueLocationX = randomXLocations[(int) (Math.random() * xSize)];
        int blueLocationY = randomYLocations[(int) (Math.random() * ySize)];
        System.out.println("Blue X = " + blueLocationX + ", Blue Y = " + blueLocationY);
        chosenXLocations.add(blueLocationX);
        
        buttonBlue.setLocation(blueLocationX, blueLocationY);
        boolean added = false;
        //RED BUTTON location
        int redLocationX = randomXLocations[(int) (Math.random() * xSize)];
        
        //used to prevent overlap of other buttons
        while(!added) {
            if (chosenXLocations.contains(redLocationX)) {
                redLocationX = randomXLocations[(int) (Math.random() * xSize)];
            }
            else {
                chosenXLocations.add(redLocationX);
                added = true;
            }
        }
        
        int redLocationY = randomYLocations[(int) (Math.random() * ySize)];
        System.out.println("Red X = " + redLocationX + ", Red Y = " + redLocationY);
        
        buttonRed.setLocation(redLocationX, redLocationY);
        
        //YELLOW BUTTON location
        added = false;
        int yellowLocationX = randomXLocations[(int) (Math.random() * xSize)];
        //used to prevent overlap of other buttons        
        while(!added) {
            if (chosenXLocations.contains(yellowLocationX)) {
                yellowLocationX = randomXLocations[(int) (Math.random() * xSize)];
            }
            else {
                chosenXLocations.add(yellowLocationX);
                added = true;
            }
        }
        int yellowLocationY = randomYLocations[(int) (Math.random() * ySize)];
        System.out.println("Yellow X = " + yellowLocationX + ", Yellow Y = " + yellowLocationY);
        
        buttonYellow.setLocation(yellowLocationX, yellowLocationY);
        
                
        //GREEN BUTTON location
        added = false;
        int greenLocationX = randomXLocations[(int) (Math.random() * xSize)];
        //used to prevent overlap of other buttons
        while(!added) {
            if (chosenXLocations.contains(greenLocationX)) {
                greenLocationX = randomXLocations[(int) (Math.random() * xSize)];
            }
            else {
                chosenXLocations.add(greenLocationX);
                added = true;
            }
        }
        int greenLocationY = randomYLocations[(int) (Math.random() * ySize)];
        System.out.println("Green X = " + greenLocationX + ", Green Y = " + greenLocationY);
        
        buttonGreen.setLocation(greenLocationX, greenLocationY);
        
        //PURPLE BUTTON location
        added = false;
        int purpleLocationX = randomXLocations[(int) (Math.random() * xSize)];
        //used to prevent overlap of other buttons
        while(!added) {
            if (chosenXLocations.contains(purpleLocationX)) {
                purpleLocationX = randomXLocations[(int) (Math.random() * xSize)];
            }
            else {
                chosenXLocations.add(purpleLocationX);
                added = true;
            }
        }
        int purpleLocationY = randomYLocations[(int) (Math.random() * ySize)];
        System.out.println("Purple X = " + purpleLocationX + ", Purple Y = " + purpleLocationY);
        
        buttonPurple.setLocation(purpleLocationX, purpleLocationY);
        //add to frame
        this.pack();
        startClock();
    }

    
    //Set the text color and content to another random color and text based on global arrays
    public void resetButtonAndText() {
        currentText = colorTxtArr[(int) (Math.random() * 5)];
        buttonColor = colorArr[(int) (Math.random() * 5)];
        colorText.setForeground(buttonColor);
        colorText.setText(currentText);
    }
    
    //When game ends, call this method
    
    public void endGame() {
        dispose();
        System.out.println("No onto Sudoku!");
        
        Pjam_Sudoku ps =  new Pjam_Sudoku();
        ps.setVisible(true);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        imageForF1 = new javax.swing.JLabel();
        colorText = new java.awt.Label();
        clockLabel = new java.awt.Label();
        buttonRed = new javax.swing.JButton();
        buttonGreen = new javax.swing.JButton();
        buttonYellow = new javax.swing.JButton();
        buttonBlue = new javax.swing.JButton();
        buttonPurple = new javax.swing.JButton();
        highscoreLabel = new java.awt.Label();
        roundsLabel = new java.awt.Label();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        imageForF1.setToolTipText("F1 to show, F2 to hide!");
        getContentPane().add(imageForF1);
        imageForF1.setBounds(10, 30, 150, 100);

        colorText.setAlignment(java.awt.Label.CENTER);
        colorText.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        colorText.setText("label for color text");
        getContentPane().add(colorText);
        colorText.setBounds(10, 50, 600, 66);

        clockLabel.setAlignment(java.awt.Label.RIGHT);
        clockLabel.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        clockLabel.setForeground(new java.awt.Color(128, 0, 128));
        clockLabel.setText("clock Label");
        getContentPane().add(clockLabel);
        clockLabel.setBounds(403, 0, 197, 30);

        buttonRed.setBackground(new java.awt.Color(255, 0, 0));
        buttonRed.setForeground(new java.awt.Color(255, 0, 0));
        buttonRed.setToolTipText("Select Red!");
        buttonRed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonRedMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonRedMouseExited(evt);
            }
        });
        buttonRed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonRedActionPerformed(evt);
            }
        });
        getContentPane().add(buttonRed);
        buttonRed.setBounds(26, 181, 83, 77);

        buttonGreen.setBackground(new java.awt.Color(0, 255, 0));
        buttonGreen.setForeground(new java.awt.Color(0, 255, 0));
        buttonGreen.setToolTipText("Select Green!");
        buttonGreen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonGreenMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonGreenMouseExited(evt);
            }
        });
        buttonGreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGreenActionPerformed(evt);
            }
        });
        getContentPane().add(buttonGreen);
        buttonGreen.setBounds(155, 181, 83, 77);

        buttonYellow.setBackground(new java.awt.Color(255, 255, 0));
        buttonYellow.setForeground(new java.awt.Color(255, 255, 0));
        buttonYellow.setToolTipText("Select Yellow!");
        buttonYellow.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonYellowMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonYellowMouseExited(evt);
            }
        });
        buttonYellow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonYellowActionPerformed(evt);
            }
        });
        getContentPane().add(buttonYellow);
        buttonYellow.setBounds(26, 269, 83, 77);

        buttonBlue.setBackground(java.awt.Color.blue);
        buttonBlue.setForeground(java.awt.Color.blue);
        buttonBlue.setToolTipText("Select Blue!");
        buttonBlue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonBlueMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonBlueMouseExited(evt);
            }
        });
        buttonBlue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBlueActionPerformed(evt);
            }
        });
        getContentPane().add(buttonBlue);
        buttonBlue.setBounds(155, 269, 83, 77);

        buttonPurple.setBackground(java.awt.Color.magenta);
        buttonPurple.setForeground(java.awt.Color.magenta);
        buttonPurple.setToolTipText("Select Purple!");
        buttonPurple.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonPurpleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonPurpleMouseExited(evt);
            }
        });
        buttonPurple.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonPurpleActionPerformed(evt);
            }
        });
        getContentPane().add(buttonPurple);
        buttonPurple.setBounds(294, 224, 83, 77);

        highscoreLabel.setAlignment(java.awt.Label.CENTER);
        highscoreLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        highscoreLabel.setForeground(new java.awt.Color(128, 0, 128));
        highscoreLabel.setText("high score label");
        getContentPane().add(highscoreLabel);
        highscoreLabel.setBounds(0, 0, 118, 30);

        roundsLabel.setAlignment(java.awt.Label.CENTER);
        roundsLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        roundsLabel.setForeground(new java.awt.Color(128, 0, 128));
        roundsLabel.setText("rounds remaining");
        getContentPane().add(roundsLabel);
        roundsLabel.setBounds(210, 0, 192, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //When button is pressed
    private void buttonRedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonRedActionPerformed
        if (buttonColor == Color.RED)  {
            highscore += 100;
        }
        highscoreLabel.setText("Highscore = " + highscore);
        roundsRemaining -= 1;
        roundsLabel.setText("Rounds Remaining: " + roundsRemaining);
        if (roundsRemaining < 1)
            endGame();
        resetButtonAndText();
        repaint();
    }//GEN-LAST:event_buttonRedActionPerformed

    private void buttonGreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGreenActionPerformed
        if (buttonColor == Color.GREEN)  {
            highscore += 100;
        }
        highscoreLabel.setText("Highscore = " + highscore);
        roundsRemaining -= 1;
        roundsLabel.setText("Rounds Remaining: " + roundsRemaining);
        if (roundsRemaining < 1)
            endGame();
        resetButtonAndText();
        repaint();
    }//GEN-LAST:event_buttonGreenActionPerformed

    private void buttonYellowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonYellowActionPerformed
        if (buttonColor == Color.YELLOW)  {
            highscore += 100;
        }
        highscoreLabel.setText("Highscore = " + highscore);
        roundsRemaining -= 1;
        roundsLabel.setText("Rounds Remaining: " + roundsRemaining);
        if (roundsRemaining < 1)
            endGame();
        resetButtonAndText();
        repaint();
    }//GEN-LAST:event_buttonYellowActionPerformed

    private void buttonBlueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBlueActionPerformed
        if (buttonColor == Color.BLUE)  {
            highscore += 100;
        }
        highscoreLabel.setText("Highscore = " + highscore);
        roundsRemaining -= 1;
        roundsLabel.setText("Rounds Remaining: " + roundsRemaining);
        if (roundsRemaining < 1)
            endGame();
        resetButtonAndText();
        repaint();
    }//GEN-LAST:event_buttonBlueActionPerformed

    private void buttonPurpleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonPurpleActionPerformed
        if (buttonColor == Color.MAGENTA)  {
            highscore += 100;
        }
        highscoreLabel.setText("Highscore = " + highscore);
        roundsRemaining -= 1;
        roundsLabel.setText("Rounds Remaining: " + roundsRemaining);
        if (roundsRemaining < 1)
            endGame();
        resetButtonAndText();
        repaint();
    }//GEN-LAST:event_buttonPurpleActionPerformed

    
    
    //When each button is hovered, change to lighter color to represent "highlight"
    private void buttonRedMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonRedMouseEntered
        buttonRed.setBackground(new Color(255, 100, 100));
        repaint();
    }//GEN-LAST:event_buttonRedMouseEntered

    private void buttonRedMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonRedMouseExited
        buttonRed.setBackground(Color.RED);
        repaint();
    }//GEN-LAST:event_buttonRedMouseExited

    private void buttonYellowMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonYellowMouseEntered
        buttonYellow.setBackground(new Color(255, 255, 200));
        repaint();
    }//GEN-LAST:event_buttonYellowMouseEntered

    private void buttonYellowMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonYellowMouseExited
        buttonYellow.setBackground(Color.YELLOW);
        repaint();
    }//GEN-LAST:event_buttonYellowMouseExited

    private void buttonGreenMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonGreenMouseEntered
        buttonGreen.setBackground(new Color(100, 255, 100));
        repaint();
    }//GEN-LAST:event_buttonGreenMouseEntered

    private void buttonGreenMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonGreenMouseExited
        buttonGreen.setBackground(Color.GREEN);
        repaint();
    }//GEN-LAST:event_buttonGreenMouseExited

    private void buttonBlueMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonBlueMouseEntered
        buttonBlue.setBackground(new Color(150, 150, 255));
        repaint();
    }//GEN-LAST:event_buttonBlueMouseEntered

    private void buttonBlueMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonBlueMouseExited
        buttonBlue.setBackground(Color.BLUE);
        repaint();
    }//GEN-LAST:event_buttonBlueMouseExited

    private void buttonPurpleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonPurpleMouseEntered
        buttonPurple.setBackground(new Color(255, 100, 255));
        repaint();
    }//GEN-LAST:event_buttonPurpleMouseEntered

    private void buttonPurpleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonPurpleMouseExited
        buttonPurple.setBackground(Color.MAGENTA);
        repaint();
    }//GEN-LAST:event_buttonPurpleMouseExited

    //time and date method
    public void startClock() {
        Timer timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                String dateTime = new Date().toString();
                
                clockLabel.setText(dateTime);
                
            }
        });
        timer.start();
    }
    
    public void displayImage(){
        imageForF1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PjamDisplayTrans.png")));
        System.out.println("Display the image!");
    }
    public void hideImage(){
        imageForF1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PjamClear.png")));
        System.out.println("Hide the image! ");
    }
    public void exitGame(){
        System.out.println("Exit program!");
        System.exit(0);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PJam_ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PJam_ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PJam_ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PJam_ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PJam_ColorGame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonBlue;
    private javax.swing.JButton buttonGreen;
    private javax.swing.JButton buttonPurple;
    private javax.swing.JButton buttonRed;
    private javax.swing.JButton buttonYellow;
    private java.awt.Label clockLabel;
    private java.awt.Label colorText;
    private java.awt.Label highscoreLabel;
    private javax.swing.JLabel imageForF1;
    private java.awt.Label roundsLabel;
    // End of variables declaration//GEN-END:variables
}
